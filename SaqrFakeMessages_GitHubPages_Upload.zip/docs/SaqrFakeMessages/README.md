# Saqr Fake Messages

Direct-install folder for the classic Revenge/Vendetta-style plugin loader.

- Adds local-only preview rows to the currently open channel.
- Uses the phone's current time when each preview is created.
- Never calls Discord's send-message function.
- Every mock row is visibly prefixed with `[LOCAL PREVIEW]`.
- Optional sender ID only works if that Discord user is already cached.

## Compatibility warning

Target reported by the user: Revenge `0980cfc-main`, Discord `346.13 (346013)`.
The Android native bridge `DCDChatManager.updateRows` and row JSON shape can differ by build.
This plugin has not been runtime-tested on the user's phone. If the hook is absent, it shows
a toast and leaves real chat rows unchanged.
