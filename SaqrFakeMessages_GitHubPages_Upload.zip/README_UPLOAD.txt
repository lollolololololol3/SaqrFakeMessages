Upload the entire docs folder to the repository root, then enable GitHub Pages from main /docs.
Expected install URL: https://lollolololololol3.github.io/SaqrFakeMessages/SaqrFakeMessages/
